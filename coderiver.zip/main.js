/*gsap
  .timeline({
    scrollTrigger: {
      trigger: ".main",
      start: "center center",
      end: "bottom top",
      markers: true,
      scrub: true,
      pin: true,
    },
  })
  .from(".colorhead", { x: innerWidth * -1 })
  .from(".colordescription", { x: innerWidth * 1 })
  .from(".gsapimg", {
    y: innerHeight * 1,
    rotate: 360,
  });*/
